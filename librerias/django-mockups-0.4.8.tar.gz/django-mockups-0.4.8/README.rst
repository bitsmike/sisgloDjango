==============
django-mockups
==============
This app aims to provide a simple way of loading masses of randomly generated
test data into your development database. You can use a management command to
load test data through command line.

Usually you add test data through the admin to see how your site looks with non
static pages. You export data by using ``dumpdata`` to send it to your
colleagues or to preserve it before you make a ``manage.py reset app`` and so
on. Your site gets more and more complex and adding test data gets more and
more annoying.

This is the usecase where mockups should help you to save time that can
actually be spent on hacking.


Installation
============
You must make the ``mockups`` package available on your python path.  Either
drop it into your project directory or install it from the python package index
with ``pip install django-mockups``.

To use the management command you must add ``'mockups'`` to the
``INSTALLED_APPS`` setting in your django settings file. You don't need to do
this if you want to use the ``mockups`` package only as library.


Management command
==================
The ``mockups`` accepts the following syntax::

    django-admin.py mockups [options] app.Model:# [app.Model:# ...]

Its nearly self explanatory. Supply names of models, prefixed with its app
name. After that, place a colon and tell the command how many objects you want
to create. Here is an example how to create three categories and twenty
entries for you blogging app::

    django-admin.py mockups blog.Category:3 blog.Entry:20

Voila! You have ready to use testing data populated to your database. The
model fields are filled with data by producing randomly generated values
depending on the type of the field. E.g. text fields are filled with lorem
ipsum dummies, date fields are populated with random dates from the last
years etc.

There are a few command line options available. Mainly to control the
behavior of related fields. If foreingkey or many to many fields should be
populated with existing data or if the related models are also generated on
the fly. Please have a look at the help page of the command for more
information::

    django-admin.py help mockups


Using mockups as tool for unittests
========================================
It has proofed that mockups have a great use for unittests. It has always
bugged me that creating complex models for testing their behaviour was
complicated. Sometimes models have strict restrictions or many related objects
which they depend on. One solution would be to use traditional fixtures
dumped from your production database. But while in development when database
schemes are changing frequently, its hard to maintain all fixtures and to know
exactly which objects are contained in the dumps etc...

Mockups to the rescue! It lets you automatically generate models and all
of their dependecies on the fly. Have a look at the following examples.

Lets start with the very basics. We create a ``Mockup`` instance for the
``Entry`` model and tell it to create ten model instances::

    from mockups import Mockup
    mockup = Mockup(Entry)
    entries = mockup.create(10)

Now you can play around and test your blog entries. By default dependecies of
foreignkeys and many to many relations are solved by randomly selecting an
already existing object of the related model. What if you don't have one yet?
You can provide the ``generate_fk`` attribute which allows the mockup
instance to follow foreignkeys by generating new related models::

    mockup = Mockup(Entry, generate_fk=True)

This generates new instance for *all* foreignkey fields of ``Entry``. Its
possible to limit this behaviour to single fields::

    mockup = Mockup(Entry, generate_fk=['author'])

This will only create new authors automatically and doesn't touch other
tables. The same is possible with many to many fields. But you need
additionally specify how many objects should be created for the m2m relation::

    mockup = Mockup(Entry, generate_m2m={'categories': (1,3)})

All created entry models get one to three new categories assigned.

Setting custom values for fields
--------------------------------
However its often necessary to be sure that a specific field must have a
specific value. This is easily achieved with the use of ``Factory``::

    class PonyFactory(Factory):
        pub_date = generators.StaticGenerator(datetime(2010, 2, 1))

    class PonyMockup(Mockup):
        factory = PonyFactory 

    mockup = PonyMockup(Entry)


More
====
There is so much more to explore which might be useful for you and your
projects:

* There are ways to register custom ``Mockup`` subclasses with models
  that are automatically used when calling ``mockups`` on the model.
* More control for related models, even with relations of related models...
  (e.g. by using ``generate_fk=['author', 'author__user']``)
* Custom constraints that are used to ensure that created the models are
  valid (e.g. ``unique`` and ``unique_together`` constraints which are
  already handled by default)

I hope to explain this in the future with more details in a documentation. It
will be written but is not finished yet. I wanted to get this project out to
support you in development. But since its only python code you can easily study
the source on your own and see in which ways it can be used. There are already
some parts documented with doc strings which might also be helpful for you.

