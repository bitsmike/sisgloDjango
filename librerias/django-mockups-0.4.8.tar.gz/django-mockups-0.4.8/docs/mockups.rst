.. _mockups:

The mockups management command
===============================
.. automodule:: mockups.management.commands.mockups
