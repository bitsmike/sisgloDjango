# -*- coding: utf-8 -*-
from django.contrib import admin
from mockups_tests.sample_app.models import Post


admin.site.register(Post)
