from __future__ import unicode_literals

from .fields_tests import *
from .widgets_tests import *
from .resources_tests import *
from .instance_loaders_tests import *
from .admin_integration_tests import *
from .base_formats_tests import *
